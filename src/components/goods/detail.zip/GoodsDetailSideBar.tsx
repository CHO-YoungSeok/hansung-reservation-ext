import React from "react";

export const GoodsDetailSidebar = ({ image }: { image: string }) => {
  return (
    <div className="goods-detail-sidebar">
      <img
        src={image}
        alt="기자재 이미지"
        className="goods-detail-image"
        onError={(e) => {
          (e.target as HTMLImageElement).src =
            "https://via.placeholder.com/300x300?text=No+Image";
        }}
      />
    </div>
  );
};
