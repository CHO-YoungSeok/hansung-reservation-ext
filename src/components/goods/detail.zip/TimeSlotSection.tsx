import React, { useState } from "react";
import "./TimeSlotSelection.css";

interface Props {
  date: string;
  onSelect: (machine: string, start: string, end: string) => void;
}

const machines = ["No.07", "No.08", "No.09", "No.10", "No.11", "No.12"];

/* 30분 단위 타임슬롯 */
const times = [
  "09:00","09:30","10:00","10:30","11:00","11:30",
  "12:00","12:30","13:00","13:30","14:00","14:30",
  "15:00","15:30","16:00","16:30","17:00","17:30",
  "18:00","18:30","19:00","19:30","20:00","20:30",
];

function TimeSlotSelection({ date, onSelect }: Props) {
  const [selectedMachine, setSelectedMachine] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  const handleClick = (machine: string, time: string) => {
    if (!start) {
      setStart(time);
      setSelectedMachine(machine);
      return;
    }
    if (start && !end) {
      setEnd(time);
      onSelect(machine, start, time);
      return;
    }
    // 재선택
    setStart(time);
    setEnd("");
    setSelectedMachine(machine);
  };

  return (
    <div className="time-selection-container">

      <table className="time-slot-table">
        <thead>
          <tr className="time-slot-header">
            <th>품목</th>
            {times.map((t) => (
              <th key={t}>{t}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {machines.map((m) => (
            <tr key={m} className="time-row">
              <td>{m}</td>
              {times.map((t) => {
                const active =
                  selectedMachine === m &&
                  start &&
                  (t === start || (end && t >= start && t <= end));

                return (
                  <td key={t}>
                    <div
                      className={`time-block ${active ? "active" : ""}`}
                      onClick={() => handleClick(m, t)}
                    />
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>

      </table>
    </div>
  );
}

export { TimeSlotSelection };
export default TimeSlotSelection;