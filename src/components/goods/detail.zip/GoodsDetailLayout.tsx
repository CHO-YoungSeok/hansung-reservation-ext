import React from "react";

export const GoodsDetailLayout = ({ children }: { children: React.ReactNode }) => {
  return <div className="goods-detail-layout">{children}</div>;
};
