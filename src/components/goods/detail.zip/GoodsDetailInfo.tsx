import React from "react";

export const GoodsDetailInfo = ({
  title,
  infoHTML
}: {
  title: string;
  infoHTML: string;
}) => {
  return (
    <aside className="goods-detail-sidebar">
      <div className="info-box">
        <h2 className="goods-detail-title">{title}</h2>
        <div
          className="section-content"
          dangerouslySetInnerHTML={{ __html: infoHTML }}
        />
      </div>
    </aside>
  );
};
