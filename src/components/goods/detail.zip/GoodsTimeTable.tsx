import React from "react";
import "./GoodsDetail.css";

export const GoodsDetailTimeTable = ({ html }: { html: string }) => {
  return (
    <div className="goods-detail-section">
      <h2 className="goods-detail-subtitle">예약 가능 시간</h2>
      <div className="goods-detail-timetable" dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  );
};
