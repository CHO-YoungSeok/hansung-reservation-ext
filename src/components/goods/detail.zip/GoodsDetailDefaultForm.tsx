import React from "react";

export const GoodsDetailDefaultForm = ({ html }: { html: string }) => {
  return (
    <section className="goods-section">
      <h3 className="section-title">기본 신청서</h3>
      <div className="section-content" dangerouslySetInnerHTML={{ __html: html }} />
    </section>
  );
};
