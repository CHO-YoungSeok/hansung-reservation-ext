import React from "react";
import "./GoodsDetail.css";

interface Props {
  selectedDate: string;
  onDateChange: (val: string) => void;
}

export const GoodsDetailDatePicker: React.FC<Props> = ({
  selectedDate,
  onDateChange,
}) => {
  return (
    <section className="goods-section">
      <h3 className="section-title">예약 날짜 선택</h3>

      <input
        type="date"
        className="date-input"
        value={selectedDate}
        onChange={(e) => onDateChange(e.target.value)}
      />
    </section>
  );
};
