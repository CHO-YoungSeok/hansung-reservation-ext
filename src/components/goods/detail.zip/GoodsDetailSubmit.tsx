import React from "react";

export const GoodsDetailSubmitBar = ({
  form,
  selectedDate,
  machine,
  startTime,
  endTime,
}: {
  form: HTMLFormElement | null;
  selectedDate: string;
  machine: string;
  startTime: string;
  endTime: string;
}) => {

  const submit = () => {
    if (!form) return alert("폼 로드 오류");

    form.querySelector<HTMLInputElement>("#prdlst")!.value = machine;
    form.querySelector<HTMLInputElement>("#lendBgndeStr")!.value = selectedDate;
    form.querySelector<HTMLInputElement>("#lendBgnTm")!.value = startTime;
    form.querySelector<HTMLInputElement>("#lendEnddeStr")!.value = selectedDate;
    form.querySelector<HTMLInputElement>("#lendEndTm")!.value = endTime;

    form.submit();
  };

  return (
    <div className="submit-bar">
      <button className="btn-submit" onClick={submit}>
        예약 신청하기
      </button>
    </div>
  );
};
