import React, { useState } from "react";
import { GoodsDetailDatePicker } from "./GoodsDatePicker";
import TimeSlotSelection from "./TimeSlotSection";
import { GoodsDetailSubmitBar } from "./GoodsDetailSubmit";

interface Props {
  infoHTML: string;
  formHTML: string;
  agreementHTML: string;
  form: HTMLFormElement | null;
}

export const GoodsDetailReservation: React.FC<Props> = ({
  infoHTML,
  formHTML,
  agreementHTML,
  form,
}) => {

  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedMachine, setSelectedMachine] = useState<string>("");
  const [startTime, setStartTime] = useState<string>("");
  const [endTime, setEndTime] = useState<string>("");

  const handleTimeSelect = (
    machine: string,
    start: string,
    end: string
  ) => {
    setSelectedMachine(machine);
    setStartTime(start);
    setEndTime(end);
  };

  return (
    <div className="goods-reservation-container">

      {/* 신청 안내 */}
      <section className="goods-section">
        <h3 className="section-title">신청 안내</h3>
        <div
          className="section-content"
          dangerouslySetInnerHTML={{ __html: infoHTML }}
        />
      </section>

      {/* 기본 신청서 */}
      <section className="goods-section">
        <h3 className="section-title">기본 신청서</h3>
        <div
          className="section-content"
          dangerouslySetInnerHTML={{ __html: formHTML }}
        />
      </section>

      {/* 예약 날짜 선택 */}
      <GoodsDetailDatePicker
        selectedDate={selectedDate}
        onDateChange={(d) => setSelectedDate(d)}
      />

      {/* 시간표 */}
      <section className="goods-section">
        <h3 className="section-title">예약 가능 시간</h3>

        <TimeSlotSelection
          date={selectedDate}
          onSelect={handleTimeSelect}
        />
      </section>

      {/* 개인정보 동의 */}
      <section className="goods-section">
        <h3 className="section-title">정보 동의</h3>
        <div
          className="section-content"
          dangerouslySetInnerHTML={{ __html: agreementHTML }}
        />
      </section>

      {/* 제출 버튼 */}
      <GoodsDetailSubmitBar
        form={form}
        selectedDate={selectedDate}
        machine={selectedMachine}
        startTime={startTime}
        endTime={endTime}
      />

    </div>
  );
};
